#include <stdio.h>
#include <string.h>

int main() {
    FILE *fp;
    int qtd, i;
    char nome[100];
    float np1, np2, pim;

    fp = fopen("alunos.txt", "a");
    if (fp == NULL) {
        printf("Erro ao abrir arquivo.\n");
        return 1;
    }

    printf("Quantos alunos deseja cadastrar? ");
    scanf("%d", &qtd);
    getchar();

    for (i = 0; i < qtd; i++) {
        printf("\n--- Aluno %d ---\n", i+1);
        printf("Nome: ");
        fgets(nome, sizeof(nome), stdin);
        nome[strcspn(nome, "\n")] = '\0';
        printf("Nota NP1: ");
        scanf("%f", &np1);
        printf("Nota NP2: ");
        scanf("%f", &np2);
        printf("Nota PIM: ");
        scanf("%f", &pim);
        getchar();
        fprintf(fp, "%s;%.2f;%.2f;%.2f\n", nome, np1, np2, pim);
    }

    fclose(fp);
    printf("\nCadastro concluido. Dados salvos em alunos.txt\n");
    return 0;
}
