import tkinter as tk
from tkinter import messagebox

ARQUIVO = "alunos.txt"

def ler_alunos():
    alunos = []
    try:
        with open(ARQUIVO, "r", encoding="utf-8") as f:
            for linha in f:
                nome, np1, np2, pim = linha.strip().split(";")
                np1 = float(np1)
                np2 = float(np2)
                pim = float(pim)
                media = (2*np1 + 2*np2 + pim) / 5
                status = "Aprovado" if media >= 7 else "Reprovado"
                alunos.append((nome, np1, np2, pim, round(media, 2), status))
    except FileNotFoundError:
        messagebox.showinfo("Aviso", "Nenhum aluno cadastrado ainda.")
    return alunos

def mostrar_alunos():
    lista.delete(1.0, tk.END)
    alunos = ler_alunos()
    if not alunos:
        lista.insert(tk.END, "Nenhum aluno cadastrado.\n")
        return
    for a in alunos:
        lista.insert(tk.END, f"Aluno: {a[0]}\n")
        lista.insert(tk.END, f"NP1: {a[1]} | NP2: {a[2]} | PIM: {a[3]} | Média: {a[4]}\n")
        lista.insert(tk.END, f"Status: {a[5]}\n")
        lista.insert(tk.END, "-"*40 + "\n")

def mostrar_ordenados():
    lista.delete(1.0, tk.END)
    alunos = ler_alunos()
    alunos.sort(key=lambda x: x[4], reverse=True)
    for a in alunos:
        lista.insert(tk.END, f"{a[0]} - Média: {a[4]} - {a[5]}\n")
    lista.insert(tk.END, "\n(Ordenado por média)\n")

def buscar_aluno():
    nome = entrada_nome.get()
    lista.delete(1.0, tk.END)
    alunos = ler_alunos()
    encontrado = False
    for a in alunos:
        if a[0].lower() == nome.lower():
            lista.insert(tk.END, f"Aluno: {a[0]}\n")
            lista.insert(tk.END, f"NP1: {a[1]} | NP2: {a[2]} | PIM: {a[3]} | Média: {a[4]}\n")
            lista.insert(tk.END, f"Status: {a[5]}\n")
            encontrado = True
    if not encontrado:
        lista.insert(tk.END, "Aluno não encontrado.\n")

def excluir_aluno():
    nome = entrada_nome.get()
    alunos = ler_alunos()
    novos = [a for a in alunos if a[0].lower() != nome.lower()]
    if len(novos) == len(alunos):
        messagebox.showinfo("Aviso", "Aluno não encontrado.")
        return
    with open(ARQUIVO, "w", encoding="utf-8") as f:
        for a in novos:
            f.write(f"{a[0]};{a[1]};{a[2]};{a[3]}\n")
    messagebox.showinfo("Sucesso", f"Aluno '{nome}' excluído.")
    mostrar_alunos()

janela = tk.Tk()
janela.title("Sistema Acadêmico")
janela.geometry("500x400")

titulo = tk.Label(janela, text="Sistema Acadêmico", font=("Arial", 14, "bold"))
titulo.pack(pady=10)

entrada_nome = tk.Entry(janela, width=30)
entrada_nome.pack()

frame_botoes = tk.Frame(janela)
frame_botoes.pack(pady=5)

tk.Button(frame_botoes, text="Mostrar Todos", command=mostrar_alunos).grid(row=0, column=0, padx=5)
tk.Button(frame_botoes, text="Buscar", command=buscar_aluno).grid(row=0, column=1, padx=5)
tk.Button(frame_botoes, text="Ordenar por Média", command=mostrar_ordenados).grid(row=0, column=2, padx=5)
tk.Button(frame_botoes, text="Excluir", command=excluir_aluno).grid(row=0, column=3, padx=5)

lista = tk.Text(janela, height=15, width=55)
lista.pack(pady=10)

mostrar_alunos()

janela.mainloop()
