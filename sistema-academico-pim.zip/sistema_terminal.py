ARQUIVO = "alunos.txt"

def cadastrar():
    qtd = int(input("Quantos alunos deseja cadastrar? "))
    with open(ARQUIVO, "a", encoding="utf-8") as f:
        for i in range(qtd):
            print(f"\n--- Aluno {i+1} ---")
            nome = input("Nome: ")
            np1 = float(input("Nota NP1: "))
            np2 = float(input("Nota NP2: "))
            pim = float(input("Nota PIM: "))
            f.write(f"{nome};{np1};{np2};{pim}\n")
    print("\nAlunos cadastrados com sucesso!\n")

def ler_alunos():
    alunos = []
    try:
        with open(ARQUIVO, "r", encoding="utf-8") as f:
            for linha in f:
                nome, np1, np2, pim = linha.strip().split(";")
                np1 = float(np1)
                np2 = float(np2)
                pim = float(pim)
                media = (2*np1 + 2*np2 + pim) / 5
                status = "Aprovado" if media >= 7 else "Reprovado"
                alunos.append([nome, np1, np2, pim, media, status])
    except FileNotFoundError:
        pass
    return alunos

def mostrar_todos():
    alunos = ler_alunos()
    if not alunos:
        print("Nenhum aluno cadastrado.\n")
        return
    print("\n--- Lista de Alunos ---")
    for a in alunos:
        print(f"Nome: {a[0]}")
        print(f"NP1: {a[1]} | NP2: {a[2]} | PIM: {a[3]} | Média: {a[4]:.2f}")
        print(f"Status: {a[5]}")
        print("-"*30)
    print()

def buscar():
    nome_busca = input("Digite o nome do aluno: ")
    alunos = ler_alunos()
    encontrado = False
    for a in alunos:
        if a[0].lower() == nome_busca.lower():
            print(f"\nAluno: {a[0]}")
            print(f"NP1: {a[1]} | NP2: {a[2]} | PIM: {a[3]} | Média: {a[4]:.2f}")
            print(f"Status: {a[5]}\n")
            encontrado = True
    if not encontrado:
        print("Aluno não encontrado.\n")

def ordenar_por_media():
    alunos = ler_alunos()
    if not alunos:
        print("Nenhum aluno cadastrado.\n")
        return
    alunos.sort(key=lambda x: x[4], reverse=True)
    print("\n--- Alunos Ordenados por Média ---")
    for a in alunos:
        print(f"{a[0]} - Média: {a[4]:.2f} - {a[5]}")
    print()

def excluir():
    nome_excluir = input("Digite o nome do aluno que deseja excluir: ")
    alunos = ler_alunos()
    novos = [a for a in alunos if a[0].lower() != nome_excluir.lower()]
    if len(novos) == len(alunos):
        print("Aluno não encontrado.\n")
        return
    with open(ARQUIVO, "w", encoding="utf-8") as f:
        for a in novos:
            f.write(f"{a[0]};{a[1]};{a[2]};{a[3]}\n")
    print("Aluno excluído com sucesso!\n")

def menu():
    while True:
        print("--- Sistema Acadêmico ---")
        print("1 - Cadastrar alunos")
        print("2 - Mostrar todos os alunos")
        print("3 - Buscar aluno por nome")
        print("4 - Mostrar alunos ordenados por média")
        print("5 - Excluir aluno")
        print("6 - Sair")
        opcao = input("Escolha uma opção: ")
        if opcao == "1":
            cadastrar()
        elif opcao == "2":
            mostrar_todos()
        elif opcao == "3":
            buscar()
        elif opcao == "4":
            ordenar_por_media()
        elif opcao == "5":
            excluir()
        elif opcao == "6":
            print("Saindo do sistema...")
            break
        else:
            print("Opção inválida.\n")

if __name__ == "__main__":
    menu()
