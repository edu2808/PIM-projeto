# Sistema Acadêmico PIM
Projeto acadêmico desenvolvido em C e Python para cadastro e consulta de alunos.
Inclui versão em terminal e versão gráfica (Tkinter).

## Estrutura
- `sistema_academico.c`: versão em linguagem C
- `sistema_terminal.py`: versão em Python (terminal)
- `sistema_tkinter.py`: versão em Python com interface gráfica Tkinter
